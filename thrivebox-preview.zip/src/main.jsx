import React from "react";
import ReactDOM from "react-dom/client";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link
} from "react-router-dom";
import "./index.css";

const Home = () => <div><h1>ThriveBox</h1><p>Welcome to your wellness companion.</p></div>;
const Nutrition = () => <div><h2>Nutrition</h2><p>Explore African & European foods.</p></div>;
const Blog = () => <div><h2>Blog</h2><p>Health & fitness tips.</p></div>;
const Assistant = () => <div><h2>Thrive Assistant</h2><p>Get your breakthrough plan here.</p></div>;

const Navbar = () => (
  <nav>
    <ul>
      <li><Link to="/">Home</Link></li>
      <li><Link to="/nutrition">Nutrition</Link></li>
      <li><Link to="/blog">Blog</Link></li>
      <li><Link to="/assistant">Assistant</Link></li>
    </ul>
  </nav>
);

const App = () => (
  <Router>
    <Navbar />
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/nutrition" element={<Nutrition />} />
      <Route path="/blog" element={<Blog />} />
      <Route path="/assistant" element={<Assistant />} />
    </Routes>
  </Router>
);

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);